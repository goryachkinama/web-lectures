'use strict';
// Учебная демонстрация. Открывайте только на localhost, без публикации в Интернет.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { WebSocketServer, WebSocket } = require('ws');

const PORT = Number(process.env.PORT || 3000);
const HOST = '127.0.0.1';
const clientsSSE = new Set();
const wss = new WebSocketServer({ noServer: true });
let state = { seq: 0, value: 100, reason: 'Запуск сервера', sentAt: Date.now() };

function publish(reason, delta = 1) {
  state = {
    seq: state.seq + 1,
    value: state.value + delta,
    reason,
    sentAt: Date.now(),
  };
  const json = JSON.stringify(state);
  for (const res of clientsSSE) res.write(`id: ${state.seq}\nevent: update\ndata: ${json}\n\n`);
  for (const ws of wss.clients) {
    if (ws.readyState === WebSocket.OPEN) ws.send(json);
  }
  return state;
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || HOST}`);
  if (req.method === 'GET' && url.pathname === '/') {
    fs.readFile(path.join(__dirname, 'index.html'), (err, data) => {
      if (err) { res.writeHead(500); res.end('Read error'); return; }
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(data);
    });
    return;
  }
  if (req.method === 'GET' && url.pathname === '/api/state') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(state));
    return;
  }
  if (req.method === 'POST' && url.pathname === '/api/increment') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(JSON.stringify(publish('Кнопка HTTP POST', 5)));
    return;
  }
  if (req.method === 'GET' && url.pathname === '/events') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.write('retry: 1500\n\n');
    res.write(`id: ${state.seq}\nevent: update\ndata: ${JSON.stringify(state)}\n\n`);
    clientsSSE.add(res);
    const keepAlive = setInterval(() => res.write(': keep-alive\n\n'), 15000);
    req.on('close', () => { clearInterval(keepAlive); clientsSSE.delete(res); });
    return;
  }
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Not Found');
});

server.on('upgrade', (req, socket, head) => {
  if (req.url !== '/ws') { socket.destroy(); return; }
  // Проверяем Origin при handshake. Для localhost-демо достаточно same-origin.
  const expectedOrigin = `http://${HOST}:${PORT}`;
  if (req.headers.origin !== expectedOrigin) { socket.destroy(); return; }
  wss.handleUpgrade(req, socket, head, (ws) => wss.emit('connection', ws, req));
});

wss.on('connection', (ws) => {
  ws.send(JSON.stringify(state));
  ws.on('message', (raw, isBinary) => {
    if (isBinary) return;
    try {
      const message = JSON.parse(raw.toString());
      if (message.type === 'increment') publish('Команда WebSocket', 5);
    } catch { /* Учебный сервер игнорирует некорректные сообщения */ }
  });
});

const ticker = setInterval(() => publish('Тик раз в секунду', 1), 1000);
server.listen(PORT, HOST, () => {
  console.log(`Откройте http://${HOST}:${PORT}`);
  console.log('Сравните /api/state, /events и /ws в Chrome DevTools → Network.');
});

function shutdown() {
  clearInterval(ticker);
  for (const res of clientsSSE) res.end();
  for (const ws of wss.clients) ws.terminate();
  server.close(() => process.exit(0));
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
