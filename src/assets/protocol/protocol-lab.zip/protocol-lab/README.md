# Лаборатория «HTTP polling → SSE → WebSocket»

Демонстрация для студентов курса веб-разработки. Все три панели показывают одно состояние сервера, но получают его по-разному. Node.js 20+, браузер Chrome/Firefox, пакет `ws`.

## Запуск

```bash
npm install
npm start
```

Откройте **http://127.0.0.1:3000**. Не публикуйте демонстрационный сервер в Интернет: в нём нет полноценной авторизации, ограничений запросов и защиты от злоупотреблений.

## Сценарий на 15 минут

1. Откройте DevTools → Network → Preserve log; обновите страницу.
2. **Polling:** найдите `/api/state`, посчитайте новые HTTP GET каждые 3 секунды. Почему значение иногда отстаёт? Каждое обращение — отдельная пара запрос/ответ.
3. **SSE:** выберите `/events`, посмотрите заголовок `Content-Type: text/event-stream`, данные вида `event: update`, `data: {...}`; запрос остаётся открытым. События идут **от сервера к браузеру**.
4. **WebSocket:** выберите `/ws`, посмотрите рукопожатие и Messages/Frames. Откройте вторую вкладку, нажмите `WebSocket send()`. Обновления увидят обе вкладки.
5. Нажмите `HTTP POST`: SSE-клиент увидит новое значение, хотя сам SSE не умеет передавать сообщение от браузера серверу.
6. Запустите `curl -N http://127.0.0.1:3000/events` в терминале. Видны настоящие текстовые SSE-фреймы.
7. Остановите сервер: SSE будет пытаться переподключиться автоматически, а WebSocket в этом учебном примере останется закрыт. Обсудите, почему reconnect — забота приложения.

## Задания студентам

- **Базовое:** добавьте отображение времени получения сообщения и сделайте polling каждые 1/5 секунд. Что происходит с частотой запросов и свежестью данных?
- **Среднее:** добавьте событие `alert` от сервера и обработчик `source.addEventListener('alert', ...)`.
- **Продвинутое:** реализуйте автоматический reconnect WebSocket с экспоненциальной задержкой, учтите остановку соединения при закрытии вкладки.
- **Архитектурное:** определите, какие данные нельзя потерять (например, деньги и заказы), и объясните, почему SSE/WebSocket сами по себе не гарантируют бизнес-доставку событий.

## Протоколы и HTTP

SSE — это **потоковый формат внутри HTTP-ответа**, а не альтернатива HTTP на транспортном уровне. WebSocket использует HTTP-рукопожатие (в демонстрации — HTTP/1.1 Upgrade) и затем обменивается WebSocket-фреймами. Существуют и варианты установления WebSocket через HTTP/2/3. WebRTC и WebTransport — отдельные продвинутые темы; они не участвуют в этой лаборатории.

## Полезные материалы

- [MDN — Using server-sent events](https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events)
- [MDN — WebSockets](https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API)
- [MDN — Writing WebSocket client applications](https://developer.mozilla.org/en-US/docs/Web/API/WebSockets_API/Writing_WebSocket_client_applications)
- [MDN — WebRTC](https://developer.mozilla.org/en-US/docs/Web/API/WebRTC_API)
- [MDN — WebTransport](https://developer.mozilla.org/en-US/docs/Web/API/WebTransport_API)
